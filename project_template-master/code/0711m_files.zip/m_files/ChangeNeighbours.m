function [changednetwork] = ChangeNeighbours(t,i,j,treshhold,network)
changednetwork = network;   
s = size(changednetwork,1); %scalar giving the size of the network
for k=-1:1 % k will be used to go to the neighbours above and below
    for l=-1:1 % l will be used to go to the neighbours left and right
        if 0 < i+k && i+k <= s && 0 < j+l && j+l <= s && ~(k==l) &&  changednetwork(i+k,j+l) == 0 && ~(k==-l) && rand()>treshhold
            %all these equalities are here to make sure we never go out of
            %the lattice and to exclude diagonal neighbours
            changednetwork(i+k,j+l) = t; %change the value of the neighbour
        end
    end
end
