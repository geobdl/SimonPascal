function [cn] = CountNeighbours(i,j,network)
cn = 0;
s = size(network,1);
for k=-1:1 % k will be used to go to the neighbours above and below
    for l=-1:1 % l will be used to go to the neighbours left and right
        if 0 < i+k && i+k <= s && 0 < j+l && j+l <= s && ~(k==l) && ~(k==-l) && ~(network(i+k,j+l)==0) 
            %all these equalities are here to make sure we never go out of
            %the lattice and to exclude diagonal neighbours
            cn = cn +1;
        end
    end
end