function [network] = GenerateNetwork(s,p) %Generate a network of size s by s with a chance of occupation p in [0,1]
network = zeros(s,s);
for i = 1:s
    for j = 1:s
        if p > rand()
            network(i,j) = 1;
        end
    end
end
imagesc(network)
end