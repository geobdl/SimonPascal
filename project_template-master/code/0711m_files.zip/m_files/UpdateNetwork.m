function [network] = UpdateNetwork(network,t,R)
s = size(network,1);
for i = 1:s 
     for j = 1:s 
            if network(i,j) == 0
                network = ChangePosition(t,i,j,R,network);
            end    
     end
end
imagesc(network)
pause()