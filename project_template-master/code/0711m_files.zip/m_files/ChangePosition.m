function [changednetwork] = ChangePosition(t,i,j,R,network) % R between 0 and 1
changednetwork = network;
s = size(changednetwork,1); %scalar giving the size of the network
cn = CountNeighbours(i,j,network);
prob = 1-(1-R)^cn;
if rand() < prob
    changednetwork(i,j) = t;
end