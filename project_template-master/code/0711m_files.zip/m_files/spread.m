%% MSSSM sopm
function [network] = spread(s,p_seed,R_start,decay,budgetfactor,quality,maxtime)
    %to test: s = 250, p_seed = 0.005, R_start = 0.1, decay = 0.05,
    %budgetfactor = 2, quality =0.01, maxtime = 1000
	breakcriteria  = 0;
	t = 0;
    network = GenerateNetwork(s,p_seed);
    matrixold = network;
	while breakcriteria ~= 3 % number of times nothing happens
        R = budgetfactor*R_start*exp(-decay*t) + quality
		network = UpdateNetwork(network,t,R);
        %% Spreading
			%########### INSERT ###########
			%###########  CODE  ###########
			%###########  HERE  ###########
		%% Count calculations, time
		t = t + 1;

		%% Break criterias
		if matrixold == network % compare old and new matrices,  
			breakcriteria = breakcriteria+1; % add up times nothing happend
            SAME_MATRIX = 1
		elseif maxtime <= t % break if something happend
			breakcriteria = 3;
            t
		else
			matrixold = network; % set up new "old" matrix for comparison
			breakcriteria = 0; % reset if something happend
		end
	end	
end

