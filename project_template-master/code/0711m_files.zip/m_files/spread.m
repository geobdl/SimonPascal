%% MSSSM sopm

function [network] = spread(s,p,R,maxtime)
	breakcriteria  = 0;
	t = 0;
    network = GenerateNetwork(s,p);
    matrixold = network;
	while breakcriteria ~= 3 % number of times nothing happens
		network = UpdateNetwork(network,t,R);
        %% Spreading
			%########### INSERT ###########
			%###########  CODE  ###########
			%###########  HERE  ###########
		%% Count calculations, time
		t = t + 1;

		%% Break criterias
		if matrixold == network % compare old and new matrices,  
			breakcriteria = breakcriteria+1; % add up times nothing happend
            SAME_MATRIX = 1
		elseif maxtime <= t % break if something happend
			breakcriteria = 3;
            t
		else
			matrixold = network; % set up new "old" matrix for comparison
			breakcriteria = 0; % reset if something happend
		end
	end	
end

